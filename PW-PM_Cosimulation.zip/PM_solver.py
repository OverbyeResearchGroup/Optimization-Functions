import json
import os
from julia.api import Julia
from julia import Main


#This function runs Powermodels opf solution then creates a json with result data
def run_powermodels_opf(m_file_path, json_output_path):
    """
    Run PowerModels OPF on a Matpower .m file, convert pg, qg, and pg_cost to MW, MVAr,
    and MW-based cost, and save a formatted JSON output.

    Parameters:
    - m_file_path (str): Path to the Matpower .m file.
    - json_output_path (str): Path to save the formatted JSON output.

    Returns:
    - bool: True if successful, False if an error occurs.
    """
    # Set Julia binary path
    os.environ['JULIA_BINDIR'] = r"C:\Users\Owner\AppData\Local\Programs\Julia-1.11.4\bin"
    
    # Initialize Julia
    julia = Julia(compiled_modules=False)
    
    # Verify input file exists
    if not os.path.exists(m_file_path):
        print(f"Matpower .m file not found at: {m_file_path}")
        return False
    
    # Assign Python variables to Julia's Main module
    Main.m_file_path = m_file_path
    Main.json_output_path = json_output_path
    
    # Run Julia code
    Main.eval("""
    using PowerModels
    using Ipopt
    using JSON

    # Load the .m file data
    data = PowerModels.parse_file(m_file_path)

    # Solve the AC OPF problem
    result = solve_ac_pf(data, Ipopt.Optimizer)

    # Extract solution
    solution = result["solution"]

    # Get base MVA (default to 100.0 if not specified)
    baseMVA = haskey(data, "baseMVA") ? data["baseMVA"] : 100.0

    # Save the modified solution to JSON
    open(json_output_path, "w") do f
        write(f, JSON.json(solution))
    end
    """)
    
    # Format the JSON output
    with open(json_output_path, 'r') as f:
        data = json.load(f)
    
    # Write formatted JSON
    with open(json_output_path, 'w') as f:
        json.dump(data, f, indent=4, sort_keys=False)
    
    # Print formatted JSON
    print(json.dumps(data, indent=4, sort_keys=False))
    
    return True